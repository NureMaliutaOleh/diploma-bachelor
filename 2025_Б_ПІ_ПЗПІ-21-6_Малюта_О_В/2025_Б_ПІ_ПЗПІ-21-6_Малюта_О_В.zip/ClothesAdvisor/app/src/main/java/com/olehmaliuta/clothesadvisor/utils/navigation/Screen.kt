package com.olehmaliuta.clothesadvisor.utils.navigation

enum class Screen {
    Registration,
    LogIn,
    ClothesList,
    OutfitList,
    EditClothingItem,
    EditOutfit,
    Generate,
    Statistics,
    Settings
}