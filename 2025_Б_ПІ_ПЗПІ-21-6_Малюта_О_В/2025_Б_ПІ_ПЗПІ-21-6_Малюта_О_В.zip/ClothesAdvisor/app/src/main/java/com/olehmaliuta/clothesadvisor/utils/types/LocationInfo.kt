package com.olehmaliuta.clothesadvisor.utils.types

data class LocationInfo(
    var nameEng: String? = null,
    var nameLocal: String? = null,
    var country: String? = null,
)