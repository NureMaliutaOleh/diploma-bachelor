package com.olehmaliuta.clothesadvisor.utils.navigation

data class NavItem(
    val route: Screen,
    val labelId: Int,
    val iconId: Int
)
