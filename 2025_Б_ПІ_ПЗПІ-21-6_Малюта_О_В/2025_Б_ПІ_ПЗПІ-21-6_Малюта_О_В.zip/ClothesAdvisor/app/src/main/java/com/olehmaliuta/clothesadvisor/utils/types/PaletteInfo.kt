package com.olehmaliuta.clothesadvisor.utils.types

data class PaletteInfo(
    val nameId: Int,
    val descriptionId: Int,
    val imageId: Int
)