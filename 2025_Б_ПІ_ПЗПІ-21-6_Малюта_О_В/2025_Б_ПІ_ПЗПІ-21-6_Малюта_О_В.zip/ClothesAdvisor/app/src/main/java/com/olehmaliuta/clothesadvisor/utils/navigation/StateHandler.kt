package com.olehmaliuta.clothesadvisor.utils.navigation

interface StateHandler {
    fun restoreState()
}