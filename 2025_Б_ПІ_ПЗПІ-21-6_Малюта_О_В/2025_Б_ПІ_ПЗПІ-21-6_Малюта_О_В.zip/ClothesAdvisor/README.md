# ClothesAdvisor Android

## Server App

[Sever](https://github.com/NureZamkovyiAnatolii/clothes-advisor-server)